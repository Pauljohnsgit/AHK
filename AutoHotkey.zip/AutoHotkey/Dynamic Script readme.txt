To make Dynamic Script.EXEs you must compile !!!

AutoHotkey.dll & msvcr.dll must be copied to Scripts.ahk Directory
To compile use AUTOHOTKEY_L Ahk2Exe.exe
set to base file v1.1.21.2 ANSI 32-bit
check use Mpress to encrypt